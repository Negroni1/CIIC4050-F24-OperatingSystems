#include <stdio.h>

#include "functions.h"

int main() {
  textHandler();
  return 0;
}
